testList = ["apple", "oragne", "pear", "kiwi", "watermelon"] 
# print(testList[0])  # print out indivaul values
# print(testList[1])  # print out indivaul values
# print(testList[2])  # print out indivaul values

print(testList)       # to print out the whole list 
print(len(testList))  # to find the sum of the objects in the list
print(testList[2:5])  # to print out a range  
print(type(testList)) # prints out the data type of the list 
print(testList[-1])   # -1 would be the last item in a list -2 would be the second to last and so on
print(testList[:4])   # will print the list ending at 4
print(testList[:4])   # will print the list begainning at 4

if "apple" in testList:                        # will test if the string in the list  
  print("Yes, 'apple' is in the fruits list") 




testList[1] = "blackcurrant"                   # will replace apple with blackcurrant 
testList[1:3] = ["blackcurrant", "watermelon"] # will replace a range of values
testList[1:3] = ["watermelon"]                 # will replace a range of values with something
testList.insert(2, "watermelon")               # will insert a value at a certain point 
testlist.append("orange")                      # will add a value at the end
testlist.insert(1, "orange").                  # will insert a value a point
tropical = ["mango", "pineapple", "papaya"].   # will add tropical to testList
testList.extend(tropical)


testList.remove("kiwi")                        # will remove a value that selected
testList.pop()                                 # If you do not specify the index, the pop() method removes the last item.
del testList[0]                                # will delate a spefic index, but if you dont specify what to remove it will delete the whole list
testList.clear()                               # will clear a index, while not delating the index 



# testList2 = [1, "cake", True] 
# print(testList2)

