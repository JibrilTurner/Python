###################################
##Created by jibril on 1/12/2023 ##
##You Fucking Muppet             ##
###################################

username = input("Enter username:")
print("Username is: " + username)

password = input("Enter Password:")
print("Password is:" + password )

