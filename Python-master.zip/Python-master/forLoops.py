for x in range(0,15,5):
    print(x)