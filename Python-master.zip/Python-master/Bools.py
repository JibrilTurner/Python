def Function():
   return True

if Function():
    print("True")
else:
    print("False")
# if the function is equal to true the first part of the if statment will be Ran  


x = 200
print(isinstance(x, int)) 
# checks if x is the same data type of 

bool("abc")
bool(123)
bool(["apple", "cherry", "banana"])
# returns true

bool(False)
bool(None)
bool(0)
bool("")
bool(())
bool([])
bool({})
# retruns false

print(10 > 9)
print(10 == 9)
print(10 < 9)
# will check wether an expression is true 