
for x in ("ass"):
    print(x)



y = "Test"
print (len(y))