favPerson = input("Enter your Someone you like:")

location = input("Where do plan on going")

timeSpent = input("how long do you plan on staying out")

print("you and " +favPerson+ " spent " + timeSpent + " hours at the " + location)