###################################
##Created by jibril on 1/12/2023 ##
##You Fucking Muppet             ##
###################################

a = input("Enter Number one:")
b = input("Enter Number two:")
opp = input ("Enter Opp")

if opp == 1:
  c = int(a)+ int(b)
  print(c)
  
elif opp == 2:
  c = int(a) - int(b)
  print(c)

elif opp == 3:
  c = int(a) * int(b)
  print(c)

else:
  c = int(a) / int(b)
  print(c)

