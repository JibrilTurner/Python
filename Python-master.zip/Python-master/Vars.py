###################################
##Created by jibril on 1/12/2023##
##You Fucking Muppet             ##
###################################

# Illegal Var Names
# 2myvar = "John"
# my-var = "John"
# my var = "John"

a = 5; 
print(a);

b = 4.211;
print(b);

c = "String" # "" AND '' are interchangble 
print(c)

d = "c"
print(d)

e = 4       
e = "Sally" 
print(e)

x = str(3)    # x will be '3'
y = int(3)    # y will be 3
z = float(3)  # z will be 3

print(type(a))
print(type(b))
print(type(c))
print(type(e))
print(type(x))
print(type(y))
print(type(z))

fruits = ["apple", "banana", "cherry"]
ax, ay, az = fruits
print(fruits)
print(ax)
print(ay)
print(az)